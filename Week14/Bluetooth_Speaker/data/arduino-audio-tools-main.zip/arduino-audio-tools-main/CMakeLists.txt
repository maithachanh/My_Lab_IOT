cmake_minimum_required(VERSION 3.16)

if (DEFINED ESP_PLATFORM)

    # idf component
    # Determine optional arduino-esp32 dependency 
    if(TARGET arduino-esp32::arduino-esp32)
        set(ARDUINO_REQUIRES arduino-esp32)
    else()
        set(ARDUINO_REQUIRES "")
    endif()


    # esp_driver_i2s esp_driver_dac needed starting idf v6.0.0
    set(AAT_REQUIRES esp_common freertos hal log nvs_flash driver esp_adc esp_http_client esp_driver_gpio esp_driver_ledc)
    if(IDF_VERSION_MAJOR GREATER_EQUAL 6)
        list(APPEND AAT_REQUIRES esp_driver_i2s esp_driver_dac)
    endif()

    idf_component_register(
        # SRC_DIRS src
        INCLUDE_DIRS src
        REQUIRES ${AAT_REQUIRES} ${ARDUINO_REQUIRES}
    )

    target_compile_options(${COMPONENT_LIB} INTERFACE -DESP32_CMAKE=1 -Wno-format )

else()

    # set the project name
    project(arduino-audio-tools)

    set(CMAKE_CXX_FLAGS_DEBUG "${CMAKE_CXX_FLAGS_DEBUG} -O0")
    set(FETCHCONTENT_UPDATES_DISCONNECTED ON)

    include(FetchContent)

    add_library(arduino-audio-tools INTERFACE)
    target_compile_options(arduino-audio-tools INTERFACE  -Wno-format )

    option(BUILD_SHARED_LIBS "Build using shared libraries" OFF)
    option(ADD_PORTAUDIO "Add Portaudio Library" OFF)
    option(ADD_ARDUINO_EMULATOR "Add Arduino Emulator Library" ON)


    # make include directory available to calling projects 
    target_include_directories (arduino-audio-tools INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/src)
    target_compile_options(arduino-audio-tools INTERFACE  -Wno-format)

    # installation of all header files
    install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/src/" # source directory
        DESTINATION "include/arduino-audio-tools" # target directory
        FILES_MATCHING # install only matched files
        PATTERN "*.h" # select header files
    )

    if (ADD_PORTAUDIO)
        # Add Portaduio for desktop build
        FetchContent_Declare(portaudio GIT_REPOSITORY "https://github.com/PortAudio/portaudio.git" GIT_TAG v19.7.0 )
        FetchContent_GetProperties(portaudio)
        if(NOT portaudio_POPULATED)
            FetchContent_Populate(portaudio)
            add_subdirectory(${portaudio_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR}/portaudio)
        endif()

    endif()


    if (ADD_ARDUINO_EMULATOR)
        # Build with Linux Arduino Emulator
        FetchContent_Declare(arduino_emulator GIT_REPOSITORY "https://github.com/pschatzmann/Arduino-Emulator.git" GIT_TAG main )
        FetchContent_GetProperties(arduino_emulator)
        if(NOT arduino_emulator_POPULATED)
            FetchContent_Populate(arduino_emulator)
            add_subdirectory(${arduino_emulator_SOURCE_DIR} ${CMAKE_CURRENT_BINARY_DIR}/emulator)
        endif()
    endif()

endif()
